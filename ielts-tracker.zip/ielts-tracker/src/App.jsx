import { useState, useMemo, useEffect, useCallback } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  BarChart, Bar, Cell, PieChart, Pie, RadarChart, Radar, PolarGrid, PolarAngleAxis,
} from "recharts";

// ─── CONSTANTS ───────────────────────────────────────────────────────────────

const SECTIONS = ["Listening", "Reading", "Writing", "Speaking"];

const BAND_SCORES = Array.from({ length: 19 }, (_, i) => (i * 0.5).toFixed(1));

const FIXED_TAGS = [
  "語彙不足", "文法エラー", "パラフレーズ見落とし", "タイムマネジメント",
  "発音・流暢さ", "スペルミス", "論理構成", "スキャニング不足",
  "ディテール聞き逃し", "接続詞の誤用",
];

const SPEAKING_SUB = ["流暢さ・一貫性", "語彙力", "文法の幅と正確さ", "発音"];
const WRITING_SUB  = ["タスク達成度", "一貫性・結束性", "語彙力", "文法の幅と正確さ"];

const SECTION_COLOR = {
  Listening: "#2563EB",
  Reading:   "#10B981",
  Writing:   "#F59E0B",
  Speaking:  "#8B5CF6",
  Overall:   "#1E3A5F",
};

const TAG_COLORS = [
  "#2563EB","#10B981","#F59E0B","#8B5CF6","#EF4444",
  "#06B6D4","#EC4899","#84CC16","#F97316","#6366F1",
];

const STORAGE_KEYS = {
  entries:    "ielts_entries",
  customTags: "ielts_custom_tags",
};

// ─── STORAGE HOOK ─────────────────────────────────────────────────────────────

function usePersistedState(key, defaultValue) {
  const [state, setState] = useState(() => {
    try {
      const saved = localStorage.getItem(key);
      return saved !== null ? JSON.parse(saved) : defaultValue;
    } catch {
      return defaultValue;
    }
  });

  const setPersistedState = useCallback((value) => {
    setState(prev => {
      const next = typeof value === "function" ? value(prev) : value;
      try { localStorage.setItem(key, JSON.stringify(next)); } catch {}
      return next;
    });
  }, [key]);

  return [state, setPersistedState];
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function calcOverall(L, R, W, S) {
  return Math.round((parseFloat(L) + parseFloat(R) + parseFloat(W) + parseFloat(S)) / 4 / 0.5) * 0.5;
}

function getTestSessions(entries) {
  const byDate = {};
  entries.forEach(e => {
    if (!byDate[e.date]) byDate[e.date] = {};
    byDate[e.date][e.section] = parseFloat(e.bandScore);
  });
  return Object.entries(byDate)
    .filter(([, sec]) => SECTIONS.every(s => sec[s] !== undefined))
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([date, sec]) => ({
      date: date.slice(5),
      Listening: sec.Listening,
      Reading:   sec.Reading,
      Writing:   sec.Writing,
      Speaking:  sec.Speaking,
      Overall:   calcOverall(sec.Listening, sec.Reading, sec.Writing, sec.Speaking),
    }));
}

function getTagFrequency(entries, customTags) {
  const allTags = [...FIXED_TAGS, ...customTags];
  const freq = {};
  allTags.forEach(t => { freq[t] = 0; });
  entries.forEach(e => e.errorTags.forEach(t => { freq[t] = (freq[t] || 0) + 1; }));
  return Object.entries(freq)
    .filter(([, v]) => v > 0)
    .sort((a, b) => b[1] - a[1])
    .map(([tag, count]) => ({ tag, count }));
}

// ─── SCORE BAND BAR ──────────────────────────────────────────────────────────

function ScoreBandBar({ score, target1 = 6.5, target2 = 8.0, label }) {
  const pct = (score / 9) * 100;
  const p1  = (target1 / 9) * 100;
  const p2  = (target2 / 9) * 100;
  return (
    <div style={{ marginBottom: 4 }}>
      {label && <div style={{ fontSize: 11, color: "#64748B", marginBottom: 2 }}>{label}</div>}
      <div style={{ position: "relative", height: 12, background: "rgba(255,255,255,.2)", borderRadius: 6, overflow: "visible" }}>
        <div style={{
          position: "absolute", left: 0, top: 0, height: "100%",
          width: `${pct}%`, background: "rgba(255,255,255,.85)",
          borderRadius: 6, transition: "width .4s ease",
        }} />
        {[{ p: p1, label: `${target1}` }, { p: p2, label: `${target2}` }].map(({ p, label: l }) => (
          <div key={l} style={{ position: "absolute", left: `${p}%`, top: -4, transform: "translateX(-50%)" }}>
            <div style={{ width: 2, height: 20, background: "rgba(255,255,255,.5)", borderRadius: 1 }} />
            <div style={{ position: "absolute", top: 20, left: "50%", transform: "translateX(-50%)",
              fontSize: 9, color: "rgba(255,255,255,.6)", whiteSpace: "nowrap" }}>{l}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── CUSTOM TOOLTIP ──────────────────────────────────────────────────────────

function ChartTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 10, padding: "10px 14px", boxShadow: "0 4px 16px rgba(0,0,0,.08)" }}>
      <div style={{ fontWeight: 700, color: "#1E3A5F", marginBottom: 6, fontSize: 13 }}>{label}</div>
      {payload.map(p => (
        <div key={p.dataKey} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, marginBottom: 2 }}>
          <span style={{ width: 8, height: 8, borderRadius: "50%", background: p.color, display: "inline-block" }} />
          <span style={{ color: "#64748B" }}>{p.dataKey}:</span>
          <span style={{ fontWeight: 600, color: "#1E3A5F" }}>{p.value}</span>
        </div>
      ))}
    </div>
  );
}

// ─── DASHBOARD ───────────────────────────────────────────────────────────────

function Dashboard({ entries }) {
  const sessions   = useMemo(() => getTestSessions(entries), [entries]);
  const recent3    = sessions.slice(-3);
  const avgOverall = recent3.length
    ? (recent3.reduce((s, r) => s + r.Overall, 0) / recent3.length).toFixed(1)
    : null;
  const avgBySection = SECTIONS.reduce((acc, s) => {
    const vals = recent3.map(r => r[s]).filter(Boolean);
    acc[s] = vals.length ? (vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1) : null;
    return acc;
  }, {});

  return (
    <div>
      {/* Hero score */}
      <div style={{
        background: "linear-gradient(135deg,#1E3A5F 0%,#2563EB 100%)",
        borderRadius: 20, padding: "28px 28px 32px", marginBottom: 20, color: "#fff",
        boxShadow: "0 8px 32px rgba(37,99,235,.25)",
      }}>
        <div style={{ fontSize: 11, opacity: .65, letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 4 }}>
          直近3回の平均 Overall
        </div>
        <div style={{ display: "flex", alignItems: "flex-end", gap: 10, marginBottom: 24 }}>
          <span style={{ fontSize: 80, fontWeight: 800, lineHeight: 1, letterSpacing: -3 }}>
            {avgOverall ?? "—"}
          </span>
          <span style={{ fontSize: 18, opacity: .6, marginBottom: 12 }}>/ 9.0</span>
        </div>
        <ScoreBandBar score={parseFloat(avgOverall) || 0} />
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 24, gap: 8 }}>
          {SECTIONS.map(s => (
            <div key={s} style={{ flex: "1 1 0" }}>
              <div style={{ fontSize: 10, opacity: .55, marginBottom: 2 }}>{s.slice(0,1)}</div>
              <div style={{ fontSize: 28, fontWeight: 700, letterSpacing: -1 }}>{avgBySection[s] ?? "—"}</div>
              <div style={{ height: 3, background: "rgba(255,255,255,.2)", borderRadius: 2, marginTop: 6 }}>
                <div style={{
                  height: "100%",
                  width: `${(parseFloat(avgBySection[s]) / 9) * 100 || 0}%`,
                  background: "#fff", borderRadius: 2,
                  transition: "width .4s ease",
                }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Mini stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 12, marginBottom: 20 }}>
        {[
          { label: "総記録数",   value: entries.length,                              unit: "件" },
          { label: "要復習",     value: entries.filter(e => e.needsReview).length,   unit: "件" },
          { label: "受験回数",   value: sessions.length,                             unit: "回" },
          { label: "目標まで",   value: avgOverall
            ? Math.max(0, 6.5 - parseFloat(avgOverall)).toFixed(1) : "—",           unit: "バンド" },
        ].map(({ label, value, unit }) => (
          <div key={label} style={{
            background: "#fff", borderRadius: 14, padding: "16px 18px",
            border: "1px solid #E2E8F0",
          }}>
            <div style={{ fontSize: 11, color: "#94A3B8", marginBottom: 4 }}>{label}</div>
            <div style={{ fontSize: 30, fontWeight: 800, color: "#1E3A5F", letterSpacing: -1 }}>
              {value}<span style={{ fontSize: 12, fontWeight: 400, color: "#94A3B8", marginLeft: 3 }}>{unit}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Score trend */}
      <div style={{ background: "#fff", borderRadius: 16, padding: "20px 20px 16px", border: "1px solid #E2E8F0" }}>
        <div style={{ fontWeight: 700, color: "#1E3A5F", fontSize: 15, marginBottom: 16 }}>スコア推移</div>
        {sessions.length === 0 ? (
          <div style={{ textAlign: "center", color: "#94A3B8", padding: "48px 0", fontSize: 14 }}>
            <div style={{ fontSize: 36, marginBottom: 10 }}>📈</div>
            L / R / W / S を同日に記録すると<br />グラフが表示されます
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={sessions} margin={{ top: 5, right: 10, left: -24, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#94A3B8" }} />
              <YAxis domain={[4, 9]} ticks={[4,5,6,7,8,9]} tick={{ fontSize: 10, fill: "#94A3B8" }} />
              <Tooltip content={<ChartTooltip />} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              {SECTIONS.map(s => (
                <Line key={s} type="monotone" dataKey={s} stroke={SECTION_COLOR[s]}
                  strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 5 }} />
              ))}
              <Line type="monotone" dataKey="Overall" stroke={SECTION_COLOR.Overall}
                strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} strokeDasharray="6 2" />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}

// ─── LOG ENTRY ────────────────────────────────────────────────────────────────

function LogEntry({ setEntries, customTags, setCustomTags }) {
  const today = new Date().toISOString().slice(0, 10);
  const [form, setForm] = useState({
    date: today, section: "Listening", bandScore: "6.0",
    subScores: {}, errorTags: [], myAnswer: "", correction: "", needsReview: false,
  });
  const [newTag, setNewTag] = useState("");
  const [saved, setSaved]   = useState(false);

  const subKeys = form.section === "Speaking" ? SPEAKING_SUB
                : form.section === "Writing"  ? WRITING_SUB : [];
  const allTags = [...FIXED_TAGS, ...customTags];

  function toggleTag(tag) {
    setForm(f => ({
      ...f,
      errorTags: f.errorTags.includes(tag)
        ? f.errorTags.filter(t => t !== tag)
        : [...f.errorTags, tag],
    }));
  }

  function addCustomTag() {
    const t = newTag.trim();
    if (t && !allTags.includes(t)) {
      setCustomTags(prev => [...prev, t]);
      setForm(f => ({ ...f, errorTags: [...f.errorTags, t] }));
    }
    setNewTag("");
  }

  function handleSave() {
    if (!form.bandScore) return;
    setEntries(prev => [...prev, { ...form, id: Date.now() }]);
    setForm({
      date: today, section: "Listening", bandScore: "6.0",
      subScores: {}, errorTags: [], myAnswer: "", correction: "", needsReview: false,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    // iOS haptic feedback
    if (window.navigator?.vibrate) window.navigator.vibrate(30);
  }

  const inputStyle = {
    width: "100%", border: "1.5px solid #E2E8F0", borderRadius: 10,
    padding: "11px 14px", fontSize: 15, color: "#1E3A5F", background: "#F8FAFC",
    outline: "none", boxSizing: "border-box", WebkitAppearance: "none",
  };
  const labelStyle = {
    fontSize: 12, fontWeight: 600, color: "#64748B",
    marginBottom: 7, display: "block", letterSpacing: .3,
  };

  return (
    <div style={{ background: "#fff", borderRadius: 16, padding: "24px 20px", border: "1px solid #E2E8F0" }}>
      <div style={{ fontWeight: 800, color: "#1E3A5F", fontSize: 17, marginBottom: 22 }}>学習・スコア記録</div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 16 }}>
        <div>
          <label style={labelStyle}>日付</label>
          <input type="date" value={form.date} style={inputStyle}
            onChange={e => setForm(f => ({ ...f, date: e.target.value }))} />
        </div>
        <div>
          <label style={labelStyle}>セクション</label>
          <select value={form.section} style={inputStyle}
            onChange={e => setForm(f => ({ ...f, section: e.target.value, subScores: {} }))}>
            {SECTIONS.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div style={{ marginBottom: 16 }}>
        <label style={labelStyle}>バンドスコア（{form.section}）</label>
        <select value={form.bandScore} style={{ ...inputStyle, fontWeight: 700, fontSize: 18 }}
          onChange={e => setForm(f => ({ ...f, bandScore: e.target.value }))}>
          {BAND_SCORES.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      {subKeys.length > 0 && (
        <div style={{ background: "#F8FAFC", borderRadius: 12, padding: "16px", marginBottom: 16, border: "1px solid #E2E8F0" }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: "#64748B", marginBottom: 12 }}>内部スコア（任意）</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 10 }}>
            {subKeys.map(k => (
              <div key={k}>
                <label style={{ ...labelStyle, fontSize: 11 }}>{k}</label>
                <select value={form.subScores[k] || ""} style={{ ...inputStyle, fontSize: 13 }}
                  onChange={e => setForm(f => ({ ...f, subScores: { ...f.subScores, [k]: e.target.value } }))}>
                  <option value="">—</option>
                  {BAND_SCORES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            ))}
          </div>
          {subKeys.every(k => form.subScores[k]) && (
            <div style={{ marginTop: 14 }}>
              <ResponsiveContainer width="100%" height={160}>
                <RadarChart data={subKeys.map(k => ({ subject: k.replace(/・/g, "/"), value: parseFloat(form.subScores[k]) }))}>
                  <PolarGrid stroke="#E2E8F0" />
                  <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10, fill: "#64748B" }} />
                  <Radar dataKey="value" stroke="#2563EB" fill="#2563EB" fillOpacity={0.15} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      )}

      <div style={{ marginBottom: 16 }}>
        <label style={labelStyle}>エラー原因タグ</label>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 7, marginBottom: 10 }}>
          {allTags.map((tag, i) => (
            <button key={tag} onClick={() => toggleTag(tag)} style={{
              padding: "6px 13px", borderRadius: 20, fontSize: 12, cursor: "pointer",
              border: "none", WebkitTapHighlightColor: "transparent",
              background: form.errorTags.includes(tag) ? TAG_COLORS[i % TAG_COLORS.length] : "#F1F5F9",
              color: form.errorTags.includes(tag) ? "#fff" : "#64748B",
              fontWeight: form.errorTags.includes(tag) ? 700 : 400,
              transition: "all .15s",
            }}>{tag}</button>
          ))}
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <input value={newTag} placeholder="タグを追加… (Enter)" style={{ ...inputStyle, flex: 1 }}
            onChange={e => setNewTag(e.target.value)}
            onKeyDown={e => e.key === "Enter" && addCustomTag()} />
          <button onClick={addCustomTag} style={{
            padding: "11px 16px", background: "#2563EB", color: "#fff", border: "none",
            borderRadius: 10, fontSize: 13, cursor: "pointer", whiteSpace: "nowrap",
            fontWeight: 600, WebkitTapHighlightColor: "transparent",
          }}>追加</button>
        </div>
      </div>

      {[
        { label: "間違えた問題 / 自分の解答", key: "myAnswer",   placeholder: "例：Q32で 'Thursday' と答えたが…" },
        { label: "正答 / 添削・改善案",       key: "correction", placeholder: "例：正解は 'Tuesday'。曜日は聞こえた瞬間に書く。" },
      ].map(({ label, key, placeholder }) => (
        <div key={key} style={{ marginBottom: 16 }}>
          <label style={labelStyle}>{label}</label>
          <textarea rows={4} placeholder={placeholder} value={form[key]} style={{ ...inputStyle, resize: "vertical" }}
            onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))} />
        </div>
      ))}

      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24 }}>
        <input type="checkbox" id="review" checked={form.needsReview}
          onChange={e => setForm(f => ({ ...f, needsReview: e.target.checked }))}
          style={{ width: 20, height: 20, accentColor: "#2563EB", cursor: "pointer" }} />
        <label htmlFor="review" style={{ fontSize: 15, color: "#1E3A5F", cursor: "pointer" }}>復習が必要</label>
      </div>

      <button onClick={handleSave} style={{
        width: "100%", padding: "16px",
        background: saved ? "#10B981" : "linear-gradient(135deg,#1E3A5F,#2563EB)",
        color: "#fff", border: "none", borderRadius: 12, fontSize: 16, fontWeight: 700,
        cursor: "pointer", transition: "background .25s",
        WebkitTapHighlightColor: "transparent",
        boxShadow: "0 4px 16px rgba(37,99,235,.3)",
      }}>
        {saved ? "✓ 保存しました" : "保存する"}
      </button>
    </div>
  );
}

// ─── REVIEW & ANALYTICS ──────────────────────────────────────────────────────

function ReviewAnalytics({ entries, customTags }) {
  const [filter, setFilter] = useState("all");
  const tagData  = useMemo(() => getTagFrequency(entries, customTags), [entries, customTags]);
  const reviewed = entries.filter(e => e.needsReview);
  const filtered = filter === "all" ? reviewed : reviewed.filter(e => e.section === filter);

  return (
    <div>
      <div style={{ background: "#fff", borderRadius: 16, padding: "20px 20px 16px", border: "1px solid #E2E8F0", marginBottom: 20 }}>
        <div style={{ fontWeight: 700, color: "#1E3A5F", fontSize: 15, marginBottom: 16 }}>弱点タグ分析</div>
        {tagData.length === 0 ? (
          <div style={{ textAlign: "center", color: "#94A3B8", padding: "48px 0", fontSize: 14 }}>
            <div style={{ fontSize: 36, marginBottom: 10 }}>🏷️</div>
            エラータグを記録するとここに集計されます
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, alignItems: "center" }}>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={tagData.slice(0, 7)} layout="vertical" margin={{ left: 4, right: 16 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#F1F5F9" />
                <XAxis type="number" tick={{ fontSize: 10, fill: "#94A3B8" }} />
                <YAxis type="category" dataKey="tag" tick={{ fontSize: 9, fill: "#64748B" }} width={85} />
                <Tooltip content={({ active, payload }) => active && payload?.length
                  ? <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 8, padding: "7px 12px", fontSize: 12 }}>
                      {payload[0].payload.tag}: <b>{payload[0].value}回</b>
                    </div> : null} />
                <Bar dataKey="count" radius={[0, 6, 6, 0]}>
                  {tagData.slice(0, 7).map((_, i) => <Cell key={i} fill={TAG_COLORS[i % TAG_COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={tagData.slice(0, 6)} dataKey="count" nameKey="tag"
                  cx="50%" cy="50%" outerRadius={72}
                  label={({ percent }) => `${(percent * 100).toFixed(0)}%`} labelLine={false}>
                  {tagData.slice(0, 6).map((_, i) => <Cell key={i} fill={TAG_COLORS[i % TAG_COLORS.length]} />)}
                </Pie>
                <Tooltip content={({ active, payload }) => active && payload?.length
                  ? <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 8, padding: "7px 12px", fontSize: 12 }}>
                      {payload[0].name}: <b>{payload[0].value}回</b>
                    </div> : null} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      <div style={{ background: "#fff", borderRadius: 16, padding: "20px 20px 16px", border: "1px solid #E2E8F0" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 10 }}>
          <div style={{ fontWeight: 700, color: "#1E3A5F", fontSize: 15 }}>
            要復習リスト <span style={{ fontWeight: 400, color: "#94A3B8", fontSize: 13 }}>({filtered.length}件)</span>
          </div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {["all", ...SECTIONS].map(s => (
              <button key={s} onClick={() => setFilter(s)} style={{
                padding: "5px 12px", borderRadius: 20, fontSize: 12, cursor: "pointer",
                border: "1px solid", transition: "all .15s",
                background: filter === s ? "#2563EB" : "transparent",
                borderColor: filter === s ? "#2563EB" : "#E2E8F0",
                color: filter === s ? "#fff" : "#64748B",
                WebkitTapHighlightColor: "transparent",
              }}>{s === "all" ? "すべて" : s.slice(0,1)}</button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <div style={{ textAlign: "center", color: "#94A3B8", padding: "48px 0", fontSize: 14 }}>
            <div style={{ fontSize: 36, marginBottom: 10 }}>
              {reviewed.length === 0 ? "📝" : "🎉"}
            </div>
            {reviewed.length === 0
              ? "「復習が必要」をオンにした記録がここに表示されます"
              : "このセクションの要復習記録はありません"}
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {filtered.slice().reverse().map(e => (
              <div key={e.id} style={{ border: "1px solid #E2E8F0", borderRadius: 14, padding: "16px", background: "#FAFCFF" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10, flexWrap: "wrap", gap: 6 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{
                      background: SECTION_COLOR[e.section], color: "#fff",
                      fontSize: 11, fontWeight: 700, padding: "3px 9px", borderRadius: 20,
                    }}>{e.section}</span>
                    <span style={{ fontSize: 11, color: "#94A3B8" }}>{e.date}</span>
                  </div>
                  <span style={{ fontSize: 20, fontWeight: 800, color: SECTION_COLOR[e.section] }}>Band {e.bandScore}</span>
                </div>

                {e.errorTags.length > 0 && (
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 5, marginBottom: 10 }}>
                    {e.errorTags.map((t, i) => (
                      <span key={t} style={{
                        background: TAG_COLORS[i % TAG_COLORS.length] + "20",
                        color: TAG_COLORS[i % TAG_COLORS.length],
                        fontSize: 11, padding: "2px 9px", borderRadius: 20, fontWeight: 600,
                      }}>{t}</span>
                    ))}
                  </div>
                )}

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                  {[
                    { label: "自分の解答",   content: e.myAnswer,   accent: "#FEF9C3" },
                    { label: "添削・改善案", content: e.correction, accent: "#DCFCE7" },
                  ].map(({ label, content, accent }) => content ? (
                    <div key={label} style={{ background: accent, borderRadius: 8, padding: "10px 12px" }}>
                      <div style={{ fontSize: 10, fontWeight: 700, color: "#64748B", marginBottom: 4, textTransform: "uppercase", letterSpacing: .5 }}>{label}</div>
                      <div style={{ fontSize: 12, color: "#1E3A5F", lineHeight: 1.65 }}>{content}</div>
                    </div>
                  ) : null)}
                </div>

                {e.subScores && Object.keys(e.subScores).length > 0 && (
                  <div style={{ marginTop: 10, display: "flex", gap: 7, flexWrap: "wrap" }}>
                    {Object.entries(e.subScores).map(([k, v]) => (
                      <div key={k} style={{ background: "#F1F5F9", borderRadius: 8, padding: "5px 10px", fontSize: 11 }}>
                        <span style={{ color: "#94A3B8" }}>{k}: </span>
                        <span style={{ fontWeight: 700, color: "#1E3A5F" }}>{v}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── APP ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [tab, setTab] = useState("dashboard");
  const [entries, setEntries]       = usePersistedState(STORAGE_KEYS.entries, []);
  const [customTags, setCustomTags] = usePersistedState(STORAGE_KEYS.customTags, []);

  // iOS safe area scroll fix
  useEffect(() => {
    document.body.style.overscrollBehavior = "none";
  }, []);

  const tabs = [
    { id: "dashboard", emoji: "📊", label: "Dashboard" },
    { id: "log",       emoji: "✏️", label: "Log" },
    { id: "review",    emoji: "🔍", label: "Review" },
  ];

  return (
    <div style={{
      minHeight: "100dvh", background: "#F8FAFC",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Hiragino Sans', 'Helvetica Neue', sans-serif",
      paddingBottom: "calc(72px + env(safe-area-inset-bottom))",
    }}>
      {/* Header */}
      <div style={{
        background: "#fff", borderBottom: "1px solid #E2E8F0",
        padding: "0 20px", position: "sticky", top: 0, zIndex: 100,
        paddingTop: "env(safe-area-inset-top)",
      }}>
        <div style={{
          maxWidth: 600, margin: "0 auto",
          display: "flex", alignItems: "center", height: 52,
        }}>
          <div style={{ fontWeight: 900, color: "#1E3A5F", fontSize: 17, letterSpacing: -.5 }}>
            IELTS<span style={{ color: "#2563EB" }}>Tracker</span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div style={{ maxWidth: 600, margin: "0 auto", padding: "20px 16px 16px" }}>
        {tab === "dashboard" && <Dashboard entries={entries} />}
        {tab === "log"       && <LogEntry setEntries={setEntries} customTags={customTags} setCustomTags={setCustomTags} />}
        {tab === "review"    && <ReviewAnalytics entries={entries} customTags={customTags} />}
      </div>

      {/* Bottom Tab Bar (iOS style) */}
      <div style={{
        position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 200,
        background: "rgba(255,255,255,.92)", backdropFilter: "blur(20px)",
        WebkitBackdropFilter: "blur(20px)",
        borderTop: "1px solid rgba(0,0,0,.08)",
        paddingBottom: "env(safe-area-inset-bottom)",
        display: "flex",
      }}>
        <div style={{ maxWidth: 600, margin: "0 auto", width: "100%", display: "flex" }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              flex: 1, padding: "10px 0 8px", border: "none", background: "transparent",
              cursor: "pointer", display: "flex", flexDirection: "column",
              alignItems: "center", gap: 3,
              WebkitTapHighlightColor: "transparent",
            }}>
              <span style={{ fontSize: 22 }}>{t.emoji}</span>
              <span style={{
                fontSize: 10, fontWeight: tab === t.id ? 700 : 400,
                color: tab === t.id ? "#2563EB" : "#94A3B8",
                letterSpacing: .2,
              }}>{t.label}</span>
              {tab === t.id && (
                <div style={{ width: 4, height: 4, borderRadius: 2, background: "#2563EB" }} />
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
