import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

// ★ GitHubリポジトリ名に合わせて変更してください
// 例: https://username.github.io/ielts-tracker/ の場合は '/ielts-tracker/'
const REPO_NAME = '/ielts-tracker/'

export default defineConfig({
  base: REPO_NAME,
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['favicon.svg', 'apple-touch-icon.png', 'icons/*.png'],
      manifest: {
        name: 'IELTS Tracker',
        short_name: 'IELTSTracker',
        description: 'IELTS学習・スコア記録アプリ',
        theme_color: '#1E3A5F',
        background_color: '#F8FAFC',
        display: 'standalone',
        orientation: 'portrait',
        scope: REPO_NAME,
        start_url: REPO_NAME,
        icons: [
          {
            src: 'icons/icon-192.png',
            sizes: '192x192',
            type: 'image/png',
          },
          {
            src: 'icons/icon-512.png',
            sizes: '512x512',
            type: 'image/png',
          },
          {
            src: 'icons/icon-512.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable',
          },
        ],
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,woff2}'],
        // オフライン時もアプリが起動できるように
        navigateFallback: `${REPO_NAME}index.html`,
        navigateFallbackDenylist: [/^\/_/, /\/[^/?]+\.[^/]+$/],
      },
    }),
  ],
})
