# IELTS Tracker PWA

iPhoneのホーム画面に追加できるIELTS学習・スコア記録アプリ。

## セットアップ（GitHub Pages でホスト）

### 1. リポジトリ作成

GitHubで新しいリポジトリを作成します（例: `ielts-tracker`）。

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/あなたのユーザー名/ielts-tracker.git
git push -u origin main
```

### 2. vite.config.js のリポジトリ名を変更

```js
// vite.config.js の先頭
const REPO_NAME = '/ielts-tracker/'  // ← リポジトリ名に合わせて変更
```

### 3. GitHub Pages を有効化

1. GitHubリポジトリ → **Settings** → **Pages**
2. Source: **GitHub Actions** を選択
3. `main` にプッシュすると自動でビルド＆デプロイ

### 4. iPhoneでホーム画面に追加

1. Safariで `https://あなたのユーザー名.github.io/ielts-tracker/` を開く
2. 共有ボタン（□↑）→「ホーム画面に追加」
3. アイコンがホーム画面に追加されます

## ローカル開発

```bash
npm install
npm run dev
```

## 機能

- 📊 **Dashboard**: 直近スコア平均・推移グラフ
- ✏️ **Log Entry**: L/R/W/S バンドスコア記録、エラータグ付け
- 🔍 **Review**: 弱点タグ分析・要復習リスト

## データ保存

データはブラウザの **localStorage** に保存されます（サーバー不要・完全プライベート）。  
端末を変える場合は手動でエクスポートが必要です（将来対応予定）。
